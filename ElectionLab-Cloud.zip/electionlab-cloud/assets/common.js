const cfg = window.ELECTIONLAB_CONFIG || {};
const configured = cfg.supabaseUrl && !cfg.supabaseUrl.includes('YOUR_') && cfg.supabaseAnonKey && !cfg.supabaseAnonKey.includes('YOUR_');
const db = configured ? window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey) : null;
const sampleForecast = {
  id:'sample', title:'2028 Presidential Forecast', subtitle:'A demonstration forecast — connect Supabase to publish your own model.', dem_name:'Democratic nominee', rep_name:'Republican nominee', dem_win_prob:58, dem_ev:286, rep_ev:252, tipping_point:'Pennsylvania', tipping_margin:0.8, simulations:50000, status:'published', published_at:new Date().toISOString(), notes:'This sample is visible until the cloud database is configured.', state_data:[
    {state:'Pennsylvania',abbr:'PA',ev:19,dem_prob:58,margin:0.8},{state:'Michigan',abbr:'MI',ev:15,dem_prob:61,margin:1.4},{state:'Wisconsin',abbr:'WI',ev:10,dem_prob:55,margin:0.4},{state:'Arizona',abbr:'AZ',ev:11,dem_prob:46,margin:-0.7},{state:'Georgia',abbr:'GA',ev:16,dem_prob:44,margin:-1.1},{state:'Nevada',abbr:'NV',ev:6,dem_prob:52,margin:0.2},{state:'North Carolina',abbr:'NC',ev:16,dem_prob:38,margin:-2.0}
  ], poll_data:[]
};
function $(s){return document.querySelector(s)}
function esc(v=''){return String(v).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function fmtDate(s){if(!s)return 'Not published';return new Intl.DateTimeFormat(undefined,{dateStyle:'medium',timeStyle:'short'}).format(new Date(s))}
function toast(msg){const el=document.createElement('div');el.className='toast';el.textContent=msg;document.body.appendChild(el);setTimeout(()=>el.remove(),2800)}
function configBanner(){if(configured)return;const b=document.createElement('div');b.className='config-banner';b.innerHTML='Cloud mode is not configured yet. The site is showing demonstration data. <a href="setup.html">Finish setup</a>.';document.body.prepend(b)}
async function latestPublished(){if(!db)return sampleForecast;const {data,error}=await db.from('forecasts').select('*').eq('status','published').order('published_at',{ascending:false}).limit(1).maybeSingle();if(error){console.error(error);return sampleForecast}return data||sampleForecast}
