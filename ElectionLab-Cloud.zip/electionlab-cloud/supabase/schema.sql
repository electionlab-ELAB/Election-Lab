-- ElectionLab cloud database
create extension if not exists pgcrypto;

create table if not exists public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.forecasts (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  subtitle text default '',
  dem_name text not null default 'Democratic nominee',
  rep_name text not null default 'Republican nominee',
  dem_win_prob numeric not null default 50 check (dem_win_prob between 0 and 100),
  dem_ev integer not null default 269 check (dem_ev between 0 and 538),
  rep_ev integer not null default 269 check (rep_ev between 0 and 538),
  tipping_point text default '',
  tipping_margin numeric not null default 0,
  simulations integer not null default 50000,
  notes text default '',
  state_data jsonb not null default '[]'::jsonb,
  poll_data jsonb not null default '[]'::jsonb,
  status text not null default 'draft' check (status in ('draft','published')),
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  published_at timestamptz
);

alter table public.admins enable row level security;
alter table public.forecasts enable row level security;

-- Public visitors may read only published forecasts.
drop policy if exists "public can read published forecasts" on public.forecasts;
create policy "public can read published forecasts" on public.forecasts
for select to anon, authenticated
using (status = 'published' or exists (select 1 from public.admins a where a.user_id = auth.uid()));

-- Only users explicitly listed in public.admins may create, edit, or delete.
drop policy if exists "admins can insert forecasts" on public.forecasts;
create policy "admins can insert forecasts" on public.forecasts
for insert to authenticated
with check (exists (select 1 from public.admins a where a.user_id = auth.uid()));

drop policy if exists "admins can update forecasts" on public.forecasts;
create policy "admins can update forecasts" on public.forecasts
for update to authenticated
using (exists (select 1 from public.admins a where a.user_id = auth.uid()))
with check (exists (select 1 from public.admins a where a.user_id = auth.uid()));

drop policy if exists "admins can delete forecasts" on public.forecasts;
create policy "admins can delete forecasts" on public.forecasts
for delete to authenticated
using (exists (select 1 from public.admins a where a.user_id = auth.uid()));

-- Admins can see their own allow-list record.
drop policy if exists "admins can read own membership" on public.admins;
create policy "admins can read own membership" on public.admins
for select to authenticated using (user_id = auth.uid());

-- IMPORTANT: After creating your Auth user, run this in SQL Editor using the
-- user's UUID shown in Authentication > Users:
-- insert into public.admins (user_id) values ('PASTE-YOUR-AUTH-USER-UUID-HERE');
